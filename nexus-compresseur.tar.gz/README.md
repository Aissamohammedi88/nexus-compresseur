# NEXUS COMPRESSEUR v10 (10F00) — la compression de modèles qui dit la vérité

Compresse **n'importe quel modèle IA lourd** par **quantification GGUF** —
le fichier qui sort reste **utilisable directement** (llama.cpp, Ollama,
LM Studio). Chaque chiffre loggué est **mesuré**, et tout modèle compressé
passe un **test d'exécution réel** (il doit générer du texte, sinon échec
annoncé).

## Pourquoi ce moteur n'est pas la v9

La v9 compressait avec LZMA et logguait des « preuves simulées ». Mesures
réelles du jour (SmolLM2-135M) :

| Méthode | Taille | Gain | Utilisable tel quel ? |
| --- | --- | --- | --- |
| F16 brut | 270,9 Mo | — | oui |
| F16 + LZMA -9 | 190,2 Mo | −29,8 % | NON (à décompresser) |
| **Q4_K_M** | **105,5 Mo** | **−61,1 %** | **OUI** |
| Q4_K_M + LZMA | 102,5 Mo | −62,1 % | NON (à décompresser) |

Leçons :
- LZMA sur poids **quantifiés** ne gagne que **+2,8 %** (les poids sont
  quasi-aléatoires, donc incompressibles).
- La quantification gagne 61 % **et** le fichier reste un modèle qui tourne.
- Sur un 7B : ~14,5 Go FP16 → ~4,1 Go Q4_K_M (−71 %). Le « <1 Go » n'existe
  pas proprement pour 7B (Q2_K ≈ 2,6 Go, et la qualité chute fort).

## Utilisation

```bash
nexus-compresseur                    # menu complet
nexus-compresseur hf HuggingFaceTB/SmolLM2-135M-Instruct mon-modele
nexus-compresseur local /chemin/vers/modele-hf mon-modele
nexus-compresseur gguf fichier.gguf  # vérifie qu'un GGUF tourne
nexus-compresseur importer fichier.gguf mon-modele   # → Ollama
nexus-compresseur ollama mistral:7b  # point de vérité sur Ollama
nexus-compresseur rapport            # chiffres mesurés uniquement
```

Niveau de quantification : `Q4_K_M` par défaut (le meilleur rapport taille
/ qualité). Alternatives : `Q5_K_M`, `Q6_K`, `Q8_0`.
Change avec `export NEXUS_QLEVEL=Q5_K_M` ou en répondant au menu.

## Pipeline (auto / hf / local)

1. **Téléchargement** Hugging Face (ou dossier local safetensors)
2. **Conversion** GGUF F16 (`convert_hf_to_gguf.py`)
3. **Quantification** (`llama-quantize`) — la vraie compression
4. **Vérification d'exécution** : le modèle DOIT générer du texte
5. **Log JSON honnête** : tailles mesurées, réduction, exécution vérifiée

llama.cpp se compile tout seul au premier lancement (5-10 min, une seule
fois). Les dépendances python (torch CPU, transformers) aussi.

## Ollama — point de vérité

Les modèles Ollama (`mistral:7b` etc.) sont **déjà quantisés en 4-bit** à
l'origine : ~4,1 Go, pas 14 Go. Re-compresser ces blobs avec LZMA ne gagne
rien et les rend inutilisables. Pour un GGUF quantifié : `importer` le
remonte dans Ollama (`ollama create`) et `ollama run mon-modele` tourne.

## Fichiers

- `nexus-compresseur` — le moteur (menu + CLI)
- `install-nexus-compresseur.sh` — l'installateur
- `logs/compression.json` — historique réel (une ligne JSON par compression)
- `compresses/` — les GGUF quantifiés produits
- `sources/` — les modèles téléchargés (supprimables après compression)
